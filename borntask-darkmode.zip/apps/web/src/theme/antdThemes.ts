// Ant Design 6 themes for both modes. darkAlgorithm derives hover/active/disabled shades;
// the tokens below pin the colours BornTask actually designs with.
import { theme, type ThemeConfig } from 'antd';
import { palette, type ThemeMode } from './palettes';

export function antdThemeFor(mode: ThemeMode): ThemeConfig {
  const c = palette(mode).color;
  return {
    algorithm: mode === 'dark' ? theme.darkAlgorithm : theme.defaultAlgorithm,
    token: {
      colorPrimary: c.brandFill,
      colorLink: c.brandText,
      colorText: c.ink,
      colorTextSecondary: c.muted,
      colorTextTertiary: c.faint,
      colorBorder: c.border,
      colorBorderSecondary: c.divider,
      colorBgLayout: c.canvas,
      colorBgContainer: c.surface,
      colorBgElevated: c.raised,
      colorFillTertiary: c.chip,
      colorBgMask: c.overlay,
      colorError: c.danger,
      colorSuccess: c.brand,
      colorWarning: c.warning,
      fontFamily: "'DM Sans', system-ui, sans-serif",
      fontSize: 14,
      borderRadius: 8,
      borderRadiusLG: 12,
      controlHeight: 36,
      boxShadow: 'none',
      boxShadowSecondary: c.shadow,
    },
  };
}
