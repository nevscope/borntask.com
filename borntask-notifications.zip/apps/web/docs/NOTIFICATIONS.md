# Notifications: spec for Cursor

**Built in this handoff:** the bell, the panel, the mock data and the API contract. Try it at `/?screen=notifications`, or click the bell in the top bar. The code is self-contained:

| File | What |
|---|---|
| `src/components/Notifications.tsx` | Bell, panel and rows |
| `src/api/notificationTypes.ts` | Zod schemas and `NotificationsApi` (move to `@borntask/shared` later) |
| `src/api/notificationQueries.ts` | Hooks; picks mock or HTTP from `VITE_USE_MOCKS` |
| `src/api/notificationsHttp.ts` | Real client |
| `src/api/notificationMockData.ts` | Fictional data and in-memory API |
| `src/lib/feedTime.ts` | "25 min", "Yesterday 19:30", Today/Yesterday/Earlier groups |
| `src/theme/notifications.css` | Panel styles |

Source column: **Design** = proposed here; confirm or change before building the server part.

## What the user sees

| Element | Behaviour |
|---|---|
| Bell | In the top bar, left of the avatar. Green badge with the unread count (99+ cap). Screen-reader label "Notifications, 3 unread". The count is polled every 30 s; switch to server-sent events when the realtime work lands. |
| Panel | Opens below the bell, 420 px wide, max 560 px tall, scrolls inside. Closes on Esc, on an outside click, or on opening a row. Under 768 px it becomes a full-screen drawer with a Close button. |
| Filters | **Unread n** (default) and **All**. Unread shows "You're all caught up" with a Show all button when empty. |
| Groups | Today, Yesterday, Earlier. Group headings stick while scrolling. |
| Row | Unread dot and green tint; avatar of who did it (a GitHub or AI badge when via GitHub or MCP; a clock icon for system reminders); one sentence; task key and title; a quote for comments, mentions and rejection reasons; time on the right ("25 min", "3 h", "Yesterday 19:30", "Mon 12 Oct"). |
| Open a row | Marks it read, opens the task drawer (`?task=KEY`) and closes the panel. |
| Mark read / unread | A small circle on the right of each row (shown on hover or focus; always shown on touch screens). |
| Mark all read | Header link; disabled when nothing is unread. |
| Rows don't jump | A read row stays where it is (just loses its tint) until the panel is reopened, even under the Unread filter. |
| Inline actions | **Approval requested** → Approve / Reject… (Reject opens the drawer, because it needs a reason). **Moved to Ready for testing** → Start testing. Both use `moveTask`, so the workflow rules apply. After an action the row shows "✓ Approved" or "✓ Moved to Testing". |
| Footer | "Notification settings" opens Profile → Notifications (designed on the canvas: `ProfileSettings`). "Kept for 90 days." |

## API (proposed; implemented by `mockNotificationsApi` and `httpNotificationsApi`)

| Method | Route | Returns |
|---|---|---|
| `listNotifications(filter, cursor?)` | `GET /me/notifications?filter=unread\|all&cursor=` | `{ items, unreadCount, nextCursor }`, newest first, 30 per page |
| `getUnreadCount()` | `GET /me/notifications/unread-count` | `{ count }`; cheap, polled by the bell |
| `markNotificationsRead(input)` | `POST /me/notifications/read` with `{ ids }` or `{ all: true }` | `{ count }` (new unread count) |
| `markNotificationUnread(id)` | `POST /me/notifications/:id/unread` | `{ count }` |

The server composes each row: `actor` (an embedded user), `taskKey`, `taskTitle`, `toStatusName` and `excerpt`. That way the panel never has to load projects. The schema is `NotificationSchema` in `types.ts`.

## Who gets what (server rules)

Never notify people about their own action. Only notify people who can see the task.

| Kind | Sent to | When | Source |
|---|---|---|---|
| `approval_requested` | Project members with the **Business** role | A task is created in, or moved back to, Idea. The drawer's "Remind" resends it to one person, at most once a day. | Design |
| `approved` | Reporter and the project's Developers | Idea → Approved | Design (canvas says "notifies Luke and the project's developers") |
| `rejected` | Reporter | Idea → Rejected; the excerpt is the reason | Design |
| `assigned` | New assignee | The assignee changes (not when people assign themselves) | Design |
| `mentioned` | Each @mentioned person | A comment or description mentions them | Design |
| `commented` | Assignee, reporter and watchers | A new comment (skipping anyone already mentioned in it) | Design |
| `status_changed` | Assignee, reporter and watchers. **Into Ready for testing: also everyone with the Tester role.** | Any move | Design |
| `test_failed` | Assignee | Testing → WIP; the excerpt is the required comment | Design |
| `due_soon` | Assignee | 08:00 in their time zone on the due day, if not done | Design |
| `overdue` | Assignee | 08:00 the day after the due date, once | Design |
| `github` | Assignee | PR opened, merged, or checks failed on a linked task | Design |
| `invite_accepted` | The inviter | Invitation accepted | Design |

**Collapsing:** the same actor, task and kind within 10 minutes updates the existing row instead of adding one: `count + 1`, the latest excerpt, a new `createdAt`, and it becomes unread again.

**Auto-read:** opening a task anywhere (drawer, link, Chat card) marks that user's notifications for the task as read.

**Retention:** 90 days, then a nightly BullMQ job deletes them.

## Other channels

In-app is always on. Email and Google Chat follow the user's `NotificationPreference` (event × channel; screen `ProfileSettings`). The proposed defaults, which are a design decision to confirm:

- **Email right away:** `approval_requested`, `mentioned`, `assigned`.
- **Daily digest at 08:00 on workdays:** due, overdue and unread mentions.
- **Google Chat direct messages:** greyed out until the v2 Chat app. Project-level Chat webhooks are separate (project settings → Google Chat).

Fan-out to email and Chat runs as worker jobs, never inside the request.

## Data model

```
Notification(id, tenant_id, user_id, kind, actor_id?, via?, project_id?, task_id?,
             to_status_id?, excerpt?, count, created_at, read_at?)
  index (user_id, read_at, created_at desc)
NotificationPreference(user_id, kind, channel, enabled)
```

## Not built yet

- Infinite scroll: `nextCursor` is in the contract; the mock returns everything.
- Realtime push (SSE), which would replace the 30 s polling.
- The phone bottom-bar "Inbox" tab (canvas `SheetMobile`) should open this same panel full screen.
