import dayjs from 'dayjs';

/** Short relative time for feeds: "Just now", "25 min", "3 h", "Yesterday 14:02", "Mon 12 Oct". */
export function timeAgo(iso: string): string {
  const t = dayjs(iso);
  const m = dayjs().diff(t, 'minute');
  if (m < 1) return 'Just now';
  if (m < 60) return `${m} min`;
  const dayDiff = dayjs().startOf('day').diff(t.startOf('day'), 'day');
  if (dayDiff === 0) return `${Math.floor(m / 60)} h`;
  if (dayDiff === 1) return `Yesterday ${t.format('HH:mm')}`;
  return t.format('ddd D MMM');
}

export type FeedGroup = 'Today' | 'Yesterday' | 'Earlier';

export function feedGroup(iso: string): FeedGroup {
  const d = dayjs().startOf('day').diff(dayjs(iso).startOf('day'), 'day');
  return d <= 0 ? 'Today' : d === 1 ? 'Yesterday' : 'Earlier';
}
