// Notifications: the bell in the top bar and the panel it opens.
// - The bell polls the unread count (30 s). The list loads only while the panel is open.
// - Unread rows are tinted with a green dot. Opening a row marks it read and opens the task drawer.
// - Rows stay in place after being read until the panel is reopened, so nothing jumps under the cursor.
// - Two kinds carry inline actions: an idea waiting for approval (Approve / Reject…) and a task
//   that reached Ready for testing (Start testing). Both go through the normal workflow rules.
// - Under 768 px the panel becomes a full-screen drawer.
import { App, Badge, Button, Drawer, Popover, Segmented, Skeleton } from 'antd';
import { useEffect, useState, type ReactNode } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useMarkNotificationUnread, useMarkNotificationsRead, useNotifications, useUnreadCount } from '../api/notificationQueries';
import type { Notification, NotificationFilter } from '../api/notificationTypes';
import { useMoveTask, useProjects } from '../api/queries';
import { feedGroup, timeAgo, type FeedGroup } from '../lib/feedTime';
import '../theme/notifications.css';
import { Avatar } from './Chips';
import { LogoMark } from './Logo';
import { useTaskParam } from './useTaskParam';

function useNarrow() {
  const query = '(max-width: 767px)';
  const [narrow, setNarrow] = useState(() => typeof window !== 'undefined' && window.matchMedia(query).matches);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const on = () => setNarrow(mq.matches);
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);
  return narrow;
}

function BellIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M6 9.5a6 6 0 0 1 12 0c0 4.6 1.6 6.4 2.5 7.2a.5.5 0 0 1-.3.8H3.8a.5.5 0 0 1-.3-.8C4.4 15.9 6 14.1 6 9.5Z" />
      <path d="M10 20.5a2.2 2.2 0 0 0 4 0" />
    </svg>
  );
}

// ---------- bell ----------
export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [params, setParams] = useSearchParams();
  const narrow = useNarrow();
  const count = useUnreadCount().data ?? 0;

  // Demo deep link: /?notifications=open (used by ?screen=notifications).
  useEffect(() => {
    if (params.get('notifications') !== 'open') return;
    setOpen(true);
    setParams((p) => {
      const next = new URLSearchParams(p);
      next.delete('notifications');
      return next;
    }, { replace: true });
  }, [params, setParams]);

  const button = (
    <Badge count={count} size="small" offset={[-4, 4]} color="#178A5C">
      <Button
        type="text"
        shape="circle"
        aria-label={count ? `Notifications, ${count} unread` : 'Notifications'}
        aria-expanded={open}
        aria-haspopup="dialog"
        icon={<BellIcon />}
        onClick={() => setOpen((o) => !o)}
        style={{ width: 36, height: 36, color: '#3A3F38' }}
      />
    </Badge>
  );

  if (narrow) {
    return (
      <>
        {button}
        <Drawer open={open} onClose={() => setOpen(false)} placement="right" width="100%" closable={false} styles={{ body: { padding: 0 } }} destroyOnHidden>
          <NotificationPanel onClose={() => setOpen(false)} fullScreen />
        </Drawer>
      </>
    );
  }

  return (
    <Popover
      open={open}
      onOpenChange={setOpen}
      trigger="click"
      placement="bottomRight"
      arrow={false}
      destroyOnHidden
      styles={{ container: { padding: 0, borderRadius: 14, boxShadow: '0 18px 40px -16px rgba(18,20,23,.28), 0 0 0 1px #E8EBE6' } }}
      content={<NotificationPanel onClose={() => setOpen(false)} />}
    >
      {button}
    </Popover>
  );
}

// ---------- panel ----------
export function NotificationPanel({ onClose, fullScreen = false }: { onClose: () => void; fullScreen?: boolean }) {
  const [filter, setFilter] = useState<NotificationFilter>('unread');
  const list = useNotifications(filter, true);
  const unread = useUnreadCount().data ?? list.data?.unreadCount ?? 0;
  const markRead = useMarkNotificationsRead();
  const { message } = App.useApp();
  const items = list.data?.items ?? [];
  const groups: FeedGroup[] = ['Today', 'Yesterday', 'Earlier'];

  return (
    <section role="dialog" aria-label="Notifications" className="bt-notif-panel" style={fullScreen ? { width: '100%', height: '100%' } : undefined}>
      <header className="bt-notif-head">
        <h2 style={{ margin: 0, fontFamily: 'var(--bt-display)', fontSize: 17, fontWeight: 600, letterSpacing: '-0.02em' }}>Notifications</h2>
        <div style={{ flex: 1 }} />
        <Button type="link" size="small" disabled={!unread} onClick={() => markRead.mutate({ all: true })} style={{ paddingInline: 4 }}>
          Mark all read
        </Button>
        {fullScreen && <Button size="small" onClick={onClose}>Close</Button>}
      </header>
      <div style={{ padding: '0 16px 10px' }}>
        <Segmented<NotificationFilter>
          size="small"
          value={filter}
          onChange={setFilter}
          options={[
            { value: 'unread', label: `Unread${unread ? ` ${unread}` : ''}` },
            { value: 'all', label: 'All' },
          ]}
        />
      </div>

      <div className="bt-notif-list" role="list" style={fullScreen ? { maxHeight: 'none', flex: 1 } : undefined}>
        {list.isLoading && <div style={{ padding: 16 }}><Skeleton active avatar paragraph={{ rows: 2 }} /></div>}

        {!list.isLoading && items.length === 0 && (
          <div className="bt-notif-empty">
            <LogoMark size={36} />
            <strong style={{ fontSize: 14 }}>{filter === 'unread' ? "You're all caught up" : 'No notifications yet'}</strong>
            <span style={{ color: '#5B6157', fontSize: 13 }}>
              {filter === 'unread' ? 'New assignments, mentions and approvals will show up here.' : 'When something needs you, it shows up here.'}
            </span>
            {filter === 'unread' && <Button size="small" onClick={() => setFilter('all')}>Show all</Button>}
          </div>
        )}

        {groups.map((g) => {
          const rows = items.filter((x) => feedGroup(x.createdAt) === g);
          if (!rows.length) return null;
          return (
            <div key={g} role="presentation">
              <div className="bt-notif-group">{g}</div>
              {rows.map((x) => <NotificationRow key={x.id} item={x} onOpen={onClose} />)}
            </div>
          );
        })}
      </div>

      <footer className="bt-notif-foot">
        <Button type="text" size="small" onClick={() => void message.info('Profile → Notifications opens here (designed on the canvas, not in this handoff).')}>
          Notification settings
        </Button>
        <span style={{ fontSize: 12, color: '#5B6157' }}>Kept for 90 days</span>
      </footer>
    </section>
  );
}

// ---------- row ----------
function NotificationRow({ item, onOpen }: { item: Notification; onOpen: () => void }) {
  const { openTask } = useTaskParam();
  const markRead = useMarkNotificationsRead();
  const markUnread = useMarkNotificationUnread();
  const move = useMoveTask();
  const projects = useProjects().data ?? [];
  const { message } = App.useApp();
  const [resolved, setResolved] = useState<string | null>(null);
  const isUnread = !item.readAt;
  const project = projects.find((p) => p.key === item.projectKey);

  const read = () => isUnread && markRead.mutate({ ids: [item.id] });
  const open = () => {
    read();
    if (item.taskKey) {
      openTask(item.taskKey);
      onOpen();
    }
  };
  const act = (toStatusId: string, done: string) => {
    if (!item.taskKey) return;
    const key = item.taskKey;
    move.mutate(
      { key, input: { toStatusId } },
      {
        onSuccess: () => {
          read();
          setResolved(done);
          void message.success(`${key} ${done.toLowerCase()}.`);
        },
        onError: (e) => void message.error(e.message),
      },
    );
  };

  const { sentence, tone } = describe(item, project?.name);
  const quote = item.excerpt && ['mentioned', 'commented', 'rejected', 'test_failed'].includes(item.kind);

  return (
    <div role="listitem" className={`bt-notif-row${isUnread ? ' unread' : ''}`}>
      <span className="bt-notif-dot" aria-hidden="true" />
      <Lead item={item} tone={tone} />
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 6 }}>
        <button className="bt-notif-open" onClick={open} aria-label={`${isUnread ? 'Unread. ' : ''}${plain(sentence)}${item.taskKey ? `, ${item.taskKey}` : ''}`}>
          <span style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
            <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.4, color: '#121417' }}>{sentence}</span>
            <span style={{ fontSize: 12, color: '#5B6157', whiteSpace: 'nowrap' }}>{timeAgo(item.createdAt)}</span>
          </span>
          {item.taskKey && (
            <span style={{ display: 'flex', gap: 6, fontSize: 12.5, color: '#5B6157', minWidth: 0 }}>
              <span style={{ fontVariantNumeric: 'tabular-nums', flex: 'none' }}>{item.taskKey}</span>
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.taskTitle}</span>
            </span>
          )}
          {quote && <span className="bt-notif-quote">{item.excerpt}</span>}
          {item.kind === 'github' && item.excerpt && <span className="bt-notif-pr">{item.excerpt}</span>}
        </button>

        {item.kind === 'approval_requested' && (
          <Actions resolved={resolved}>
            <Button size="small" type="primary" loading={move.isPending} onClick={() => act('approved', 'Approved')}>Approve</Button>
            <Button size="small" onClick={open}>Reject…</Button>
          </Actions>
        )}
        {item.kind === 'status_changed' && item.toStatusId === 'ready' && (
          <Actions resolved={resolved}>
            <Button size="small" loading={move.isPending} onClick={() => act('testing', 'Moved to Testing')}>Start testing</Button>
          </Actions>
        )}
      </div>
      <button
        className="bt-notif-toggle"
        title={isUnread ? 'Mark as read' : 'Mark as unread'}
        aria-label={isUnread ? 'Mark as read' : 'Mark as unread'}
        onClick={() => (isUnread ? markRead.mutate({ ids: [item.id] }) : markUnread.mutate(item.id))}
      >
        <span className={isUnread ? 'filled' : ''} />
      </button>
    </div>
  );
}

function Actions({ resolved, children }: { resolved: string | null; children: ReactNode }) {
  if (resolved) return <span style={{ fontSize: 12.5, color: '#0F6B46', fontWeight: 600 }}>✓ {resolved}</span>;
  return <span style={{ display: 'flex', gap: 8 }} onClick={(e) => e.stopPropagation()}>{children}</span>;
}

type Tone = 'person' | 'due' | 'overdue';

function Lead({ item, tone }: { item: Notification; tone: Tone }) {
  if (!item.actor) {
    const c = tone === 'overdue' ? { bg: '#FDECEC', fg: '#B42323' } : { bg: '#FFF4E0', fg: '#8A5A00' };
    return (
      <span aria-hidden="true" style={{ width: 32, height: 32, borderRadius: '50%', background: c.bg, color: c.fg, display: 'grid', placeItems: 'center', flex: 'none' }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></svg>
      </span>
    );
  }
  return (
    <span style={{ position: 'relative', flex: 'none', height: 32 }}>
      <Avatar user={item.actor} size={32} />
      {item.via && item.via !== 'app' && (
        <span title={`via ${viaLabel[item.via]}`} className="bt-notif-via">
          {item.via === 'github' ? (
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round"><circle cx="6" cy="5" r="2.2" /><circle cx="6" cy="19" r="2.2" /><circle cx="18" cy="8" r="2.2" /><path d="M6 7.2v9.6M18 10.2c0 4-4 4.5-10 7" /></svg>
          ) : (
            <span style={{ fontSize: 8, fontWeight: 700, color: '#fff' }}>AI</span>
          )}
        </span>
      )}
    </span>
  );
}

const viaLabel = { app: 'BornTask', mcp: 'Claude (MCP)', github: 'GitHub', import: 'import' } as const;

/** One sentence per kind. The actor's name is bold; everything else is plain. */
function describe(x: Notification, projectName?: string): { sentence: ReactNode; tone: Tone } {
  const who = <strong style={{ fontWeight: 600 }}>{x.actor?.name}</strong>;
  const status = <strong style={{ fontWeight: 600 }}>{x.toStatusName}</strong>;
  switch (x.kind) {
    case 'approval_requested':
      return { sentence: <>{who} raised an idea that needs your approval</>, tone: 'person' };
    case 'approved':
      return { sentence: <>{who} approved your idea. Work can start.</>, tone: 'person' };
    case 'rejected':
      return { sentence: <>{who} rejected your idea</>, tone: 'person' };
    case 'assigned':
      return { sentence: <>{who} assigned you</>, tone: 'person' };
    case 'mentioned':
      return { sentence: <>{who} mentioned you</>, tone: 'person' };
    case 'commented':
      return { sentence: x.count > 1 ? <>{who} added {x.count} comments</> : <>{who} commented</>, tone: 'person' };
    case 'status_changed':
      return {
        sentence: x.toStatusId === 'ready' ? <>{who} moved it to {status}. Ready for you to test.</> : <>{who} moved it to {status}</>,
        tone: 'person',
      };
    case 'test_failed':
      return { sentence: <>{who} failed the test. Back to <strong style={{ fontWeight: 600 }}>WIP</strong>.</>, tone: 'person' };
    case 'due_soon':
      return { sentence: <><strong style={{ fontWeight: 600 }}>Due today</strong></>, tone: 'due' };
    case 'overdue':
      return { sentence: <><strong style={{ fontWeight: 600, color: '#B42323' }}>Overdue</strong> and not done yet</>, tone: 'overdue' };
    case 'github':
      return { sentence: <>{who} opened a pull request</>, tone: 'person' };
    case 'invite_accepted':
      return { sentence: <>{who} accepted your invitation to <strong style={{ fontWeight: 600 }}>{projectName ?? x.projectKey}</strong></>, tone: 'person' };
  }
}

/** Screen-reader text for a sentence node. */
function plain(node: ReactNode): string {
  if (node === null || node === undefined || typeof node === 'boolean') return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(plain).join('');
  if (typeof node === 'object' && 'props' in node) return plain((node.props as { children?: ReactNode }).children);
  return '';
}
