// Notifications: API contract (proposed). Self-contained so it can be dropped into an existing
// apps/web; move into @borntask/shared with the other schemas when the monorepo is ready.
import { z } from 'zod';
import { ActorViaSchema, UserSchema } from './types';

// One row per event the signed-in user should hear about. The server composes the row (names,
// titles, status names) so the panel renders without loading every project. Events by the same
// actor on the same task within 10 minutes are collapsed into one row with `count` > 1.
export const NotificationKindSchema = z.enum([
  'approval_requested', // an Idea needs my Business approval
  'approved', // an idea I raised was approved
  'rejected', // an idea I raised was rejected (excerpt = reason)
  'assigned', // I was made the assignee
  'mentioned', // someone @mentioned me (excerpt = comment)
  'commented', // new comments on a task I'm assigned to or watching
  'status_changed', // a task I'm on moved (toStatusName); "Ready for testing" is the tester's cue
  'test_failed', // my task failed testing and went back to WIP (excerpt = reason)
  'due_soon', // due today (sent at 08:00 in my time zone)
  'overdue', // past due and not done
  'github', // a PR or branch event on a task I'm on (excerpt = PR title)
  'invite_accepted', // someone I invited joined
]);
export type NotificationKind = z.infer<typeof NotificationKindSchema>;

export const NotificationSchema = z.object({
  id: z.string(),
  kind: NotificationKindSchema,
  /** Who did it; null for system events (due dates, overdue). Embedded so the panel needs no user lookup. */
  actor: UserSchema.nullable(),
  via: ActorViaSchema.nullable(),
  projectKey: z.string().nullable(),
  taskKey: z.string().nullable(),
  taskTitle: z.string().nullable(),
  toStatusId: z.string().nullable(),
  toStatusName: z.string().nullable(),
  /** Comment text, rejection reason or PR title, already trimmed to ~140 characters. */
  excerpt: z.string().nullable(),
  count: z.number().int().min(1),
  createdAt: z.string(),
  readAt: z.string().nullable(),
});
export type Notification = z.infer<typeof NotificationSchema>;

export const NotificationFilterSchema = z.enum(['unread', 'all']);
export type NotificationFilter = z.infer<typeof NotificationFilterSchema>;

export const NotificationPageSchema = z.object({
  items: z.array(NotificationSchema),
  unreadCount: z.number().int(),
  /** Opaque cursor for the next 30 rows; null at the end. */
  nextCursor: z.string().nullable(),
});
export type NotificationPage = z.infer<typeof NotificationPageSchema>;

export const UnreadCountSchema = z.object({ count: z.number().int() });

export const MarkReadInputSchema = z.union([
  z.object({ ids: z.array(z.string()).min(1) }),
  z.object({ all: z.literal(true) }),
]);
export type MarkReadInput = z.infer<typeof MarkReadInputSchema>;

/** Kept separate from the main `Api` interface so adding notifications touches no existing file. */
export interface NotificationsApi {
  listNotifications(filter: NotificationFilter, cursor?: string): Promise<NotificationPage>; // GET /me/notifications?filter=unread&cursor=
  getUnreadCount(): Promise<number>; // GET /me/notifications/unread-count  → { count }  (polled by the bell)
  markNotificationsRead(input: MarkReadInput): Promise<number>; // POST /me/notifications/read  { ids } | { all: true }  → { count }
  markNotificationUnread(id: string): Promise<number>; // POST /me/notifications/:id/unread  → { count }
}
