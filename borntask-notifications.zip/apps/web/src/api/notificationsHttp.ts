// Notifications: real HTTP client. Same conventions as http.ts (session cookie, Zod-validated responses).
import { z } from 'zod';
import { ApiError } from './http';
import { ApiErrorBodySchema } from './types';
import { NotificationPageSchema, UnreadCountSchema, type NotificationsApi } from './notificationTypes';

const BASE_URL: string = import.meta.env.VITE_API_URL ?? '/api';

async function call<T>(method: 'GET' | 'POST', path: string, schema: z.ZodType<T>, body?: unknown): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    credentials: 'include',
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) {
    const parsed = ApiErrorBodySchema.safeParse(await res.json().catch(() => null));
    if (parsed.success) throw new ApiError(res.status, parsed.data.code, parsed.data.message, parsed.data.allowedRoles);
    throw new ApiError(res.status, res.status === 401 ? 'UNAUTHORIZED' : 'SERVER', res.statusText);
  }
  return schema.parse(await res.json());
}

export const httpNotificationsApi: NotificationsApi = {
  listNotifications: (filter, cursor) =>
    call('GET', `/me/notifications?filter=${filter}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`, NotificationPageSchema),
  getUnreadCount: async () => (await call('GET', '/me/notifications/unread-count', UnreadCountSchema)).count,
  markNotificationsRead: async (input) => (await call('POST', '/me/notifications/read', UnreadCountSchema, input)).count,
  markNotificationUnread: async (id) => (await call('POST', `/me/notifications/${encodeURIComponent(id)}/unread`, UnreadCountSchema)).count,
};
