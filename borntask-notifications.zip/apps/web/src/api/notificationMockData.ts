// Notifications: fictional sample data and an in-memory implementation of NotificationsApi.
// Signed-in user is Scope (owner; Business + Tester on every project). Three unread, as on the canvas.
// People are inlined so this file does not depend on mockData.ts.
import dayjs from 'dayjs';
import type { User } from './types';
import type { Notification, NotificationsApi } from './notificationTypes';

const people: User[] = [
  { id: 'u_maria', name: 'Maria Borg', email: 'maria@example.com', initials: 'MB' },
  { id: 'u_luke', name: 'Luke Camilleri', email: 'luke@example.com', initials: 'LC' },
  { id: 'u_daniela', name: 'Daniela Vella', email: 'daniela@example.com', initials: 'DV' },
  { id: 'u_karl', name: 'Karl Farrugia', email: 'karl@example.com', initials: 'KF' },
];

const LATENCY_MS = 140;
const wait = () => new Promise<void>((r) => setTimeout(r, LATENCY_MS));
const clone = <T>(v: T): T => structuredClone(v);

const mins = (m: number) => dayjs().subtract(m, 'minute').toISOString();
type NotificationSeed = Partial<Omit<Notification, 'actor'>> & Pick<Notification, 'id' | 'kind' | 'createdAt'> & { actorId?: string };
const n = ({ actorId, ...p }: NotificationSeed): Notification => ({
  actor: people.find((u) => u.id === actorId) ?? null,
  via: 'app',
  projectKey: p.taskKey ? p.taskKey.split('-')[0]! : null,
  taskKey: null,
  taskTitle: null,
  toStatusId: null,
  toStatusName: null,
  excerpt: null,
  count: 1,
  readAt: null,
  ...p,
});
let notifications: Notification[] = [
  n({ id: 'n_1', kind: 'approval_requested', actorId: 'u_luke', taskKey: 'WEB-160', taskTitle: 'Customer reviews on product pages', createdAt: mins(25) }),
  n({ id: 'n_2', kind: 'mentioned', actorId: 'u_maria', taskKey: 'MOB-27', taskTitle: 'Review push notification copy', excerpt: '@Scope the new copy is on staging. Can you sign it off before 3pm?', createdAt: mins(48) }),
  n({ id: 'n_3', kind: 'status_changed', actorId: 'u_karl', taskKey: 'WEB-133', taskTitle: 'Lazy-load hero and product images', toStatusId: 'ready', toStatusName: 'Ready for testing', createdAt: mins(75) }),
  n({ id: 'n_4', kind: 'github', actorId: 'u_karl', via: 'github', taskKey: 'WEB-142', taskTitle: 'Checkout fails on Safari 17', excerpt: '#231 Fix 3-D Secure redirect on Safari', createdAt: mins(190), readAt: mins(150) }),
  n({ id: 'n_5', kind: 'due_soon', via: null, taskKey: 'MOB-27', taskTitle: 'Review push notification copy', createdAt: dayjs().hour(8).minute(0).second(0).toISOString(), readAt: mins(60) }),
  n({ id: 'n_6', kind: 'commented', actorId: 'u_karl', taskKey: 'WEB-142', taskTitle: 'Checkout fails on Safari 17', excerpt: 'Fixed the polyfill and deployed to staging. Moved to Testing.', count: 3, createdAt: mins(60 * 22), readAt: mins(60 * 20) }),
  n({ id: 'n_7', kind: 'assigned', actorId: 'u_daniela', taskKey: 'CLI-12', taskTitle: 'Welcome email sequence for new clients', createdAt: mins(60 * 27), readAt: mins(60 * 26) }),
  n({ id: 'n_8', kind: 'overdue', via: null, taskKey: 'WEB-151', taskTitle: 'Hero copy for the autumn campaign', createdAt: mins(60 * 30), readAt: mins(60 * 29) }),
  n({ id: 'n_9', kind: 'approved', actorId: 'u_daniela', taskKey: 'WEB-151', taskTitle: 'Hero copy for the autumn campaign', toStatusName: 'Approved', createdAt: mins(60 * 52), readAt: mins(60 * 50) }),
  n({ id: 'n_10', kind: 'rejected', actorId: 'u_maria', taskKey: 'MOB-19', taskTitle: 'Sign in with Apple on the login screen', excerpt: 'Not this quarter. Let us revisit after the relaunch.', createdAt: mins(60 * 75), readAt: mins(60 * 70) }),
  n({ id: 'n_11', kind: 'invite_accepted', actorId: 'u_daniela', projectKey: 'CLI', excerpt: 'Client onboarding', createdAt: mins(60 * 98), readAt: mins(60 * 96) }),
];

// Demo only: a new mention arrives 40 s after the app loads, so you can watch the bell update
// (the bell polls every 30 s; the real API can push over server-sent events later).
setTimeout(() => {
  notifications = [
    n({ id: 'n_live', kind: 'mentioned', actorId: 'u_karl', taskKey: 'WEB-147', taskTitle: 'Rate-limit the login endpoint', excerpt: '@Scope rate limit is on staging. 20 requests a minute per IP. OK to test?', createdAt: new Date().toISOString() }),
    ...notifications,
  ];
}, 40_000);

const unread = () => notifications.filter((x) => !x.readAt).length;

export const mockNotificationsApi: NotificationsApi = {
  async listNotifications(filter) {
    await wait();
    const items = notifications.filter((x) => filter === 'all' || !x.readAt).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return { items: clone(items), unreadCount: unread(), nextCursor: null };
  },

  async getUnreadCount() {
    await wait();
    return unread();
  },

  async markNotificationsRead(input) {
    await wait();
    const now = new Date().toISOString();
    const ids = 'all' in input ? null : new Set(input.ids);
    notifications = notifications.map((x) => (!x.readAt && (!ids || ids.has(x.id)) ? { ...x, readAt: now } : x));
    return unread();
  },

  async markNotificationUnread(id) {
    await wait();
    notifications = notifications.map((x) => (x.id === id ? { ...x, readAt: null } : x));
    return unread();
  },
};
