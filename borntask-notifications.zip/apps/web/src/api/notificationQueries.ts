// Notifications: TanStack Query hooks. Uses the same VITE_USE_MOCKS switch as queries.ts.
import { useMutation, useQuery, useQueryClient, type QueryClient } from '@tanstack/react-query';
import { USE_MOCKS } from './queries';
import { mockNotificationsApi } from './notificationMockData';
import { httpNotificationsApi } from './notificationsHttp';
import type { MarkReadInput, NotificationFilter, NotificationPage, NotificationsApi } from './notificationTypes';

export const notificationsApi: NotificationsApi = USE_MOCKS ? mockNotificationsApi : httpNotificationsApi;

export const nqk = {
  list: (filter: NotificationFilter) => ['notifications', filter] as const,
  unreadCount: ['notifications', 'unread-count'] as const,
};

/** The bell polls the cheap count; the list loads only while the panel is open. Swap polling for SSE later. */
export const POLL_MS = 30_000;

export const useUnreadCount = () =>
  useQuery({ queryKey: nqk.unreadCount, queryFn: () => notificationsApi.getUnreadCount(), refetchInterval: POLL_MS });

export const useNotifications = (filter: NotificationFilter, enabled: boolean) =>
  useQuery({
    queryKey: nqk.list(filter),
    queryFn: () => notificationsApi.listNotifications(filter),
    enabled,
    staleTime: 0,
    refetchInterval: enabled ? POLL_MS : false,
  });

/** Patch readAt in every cached list. Rows stay where they are until the panel is reopened, so nothing jumps under the cursor. */
function patchNotifications(qc: QueryClient, match: (id: string) => boolean, readAt: string | null) {
  const lists = { queryKey: ['notifications'], predicate: (q: { queryKey: readonly unknown[] }) => q.queryKey[1] !== 'unread-count' };
  const snapshots = qc.getQueriesData<NotificationPage>(lists);
  qc.setQueriesData<NotificationPage>(lists, (page) => page && { ...page, items: page.items.map((x) => (match(x.id) ? { ...x, readAt } : x)) });
  const previousCount = qc.getQueryData<number>(nqk.unreadCount);
  return () => {
    for (const [key, data] of snapshots) qc.setQueryData(key, data);
    qc.setQueryData(nqk.unreadCount, previousCount);
  };
}

export function useMarkNotificationsRead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: MarkReadInput) => notificationsApi.markNotificationsRead(input),
    onMutate: (input) => {
      const ids = 'all' in input ? null : new Set(input.ids);
      const rollback = patchNotifications(qc, (id) => !ids || ids.has(id), new Date().toISOString());
      const count = qc.getQueryData<number>(nqk.unreadCount);
      if (count !== undefined) qc.setQueryData(nqk.unreadCount, ids ? Math.max(0, count - ids.size) : 0);
      return { rollback };
    },
    onError: (_e, _v, ctx) => ctx?.rollback(),
    onSuccess: (count) => qc.setQueryData(nqk.unreadCount, count),
  });
}

export function useMarkNotificationUnread() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => notificationsApi.markNotificationUnread(id),
    onMutate: (id) => ({ rollback: patchNotifications(qc, (x) => x === id, null) }),
    onError: (_e, _v, ctx) => ctx?.rollback(),
    onSuccess: (count) => qc.setQueryData(nqk.unreadCount, count),
  });
}
