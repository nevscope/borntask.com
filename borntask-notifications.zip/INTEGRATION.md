# Add notifications to BornTask (drop-in)

Seven new files plus one spec. **No existing file is replaced.** Only two small edits are needed.

## 1. Copy the files (all new)

```
apps/web/src/components/Notifications.tsx    bell, panel, rows
apps/web/src/api/notificationTypes.ts        Zod schemas + NotificationsApi
apps/web/src/api/notificationQueries.ts      TanStack Query hooks (mock/HTTP switch)
apps/web/src/api/notificationsHttp.ts        real client
apps/web/src/api/notificationMockData.ts     fictional data, in-memory API
apps/web/src/lib/feedTime.ts                 "25 min" / Today-Yesterday-Earlier
apps/web/src/theme/notifications.css         panel styles (imported by Notifications.tsx)
apps/web/docs/NOTIFICATIONS.md               spec: API, who gets what, collapsing, retention, channels
```

## 2. Put the bell in the top bar (`src/components/AppShell.tsx`)

```tsx
import { NotificationBell } from './Notifications';
// ...in the top bar, just before the avatar:
<NotificationBell />
```

## 3. Optional: demo link (`src/App.tsx`)

Add this to `DEMO_SCREENS` so `/?screen=notifications` opens the panel:

```ts
notifications: { path: '/?notifications=open' },
```

## What it expects from the existing app

These come from the original `apps/web` handoff. If you renamed any of them, update the imports at the top of `Notifications.tsx` and the new `api/notification*.ts` files.

| Import | From |
|---|---|
| `useMoveTask`, `useProjects`, `USE_MOCKS` | `src/api/queries.ts` |
| `ApiError` | `src/api/http.ts` |
| `ApiErrorBodySchema`, `ActorViaSchema`, `UserSchema`, `User` | `src/api/types.ts` |
| `Avatar` | `src/components/Chips.tsx` |
| `LogoMark` | `src/components/Logo.tsx` |
| `useTaskParam` | `src/components/useTaskParam.ts` |
| CSS variables `--bt-brand`, `--bt-border`, `--bt-surface`, `--bt-subtle`, `--bt-muted`, `--bt-display` | `src/theme/global.css` |

`antd`, `@tanstack/react-query`, `react-router-dom`, `dayjs` and `zod` are already dependencies. Nothing new to install.

## Check it

```bash
npm run typecheck
npm run dev   # then click the bell, or open /?screen=notifications (if you did step 3)
```

With `VITE_USE_MOCKS=true` you should see 3 unread. A new mention arrives about 40 s after load. Approve on WEB-160 moves it to Approved.

**Mock note:** one sample row ("Maria Borg rejected your idea") points at **MOB-19**. If your mock data has no MOB-19, the drawer shows "not found" for that row only. Either add the task or change the key in `notificationMockData.ts`.
